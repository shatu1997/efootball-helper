# eFootball Helper Android project

Features:
- English Attack/Defense tips
- Argentina and formation helper
- Local match result tracker (SharedPreferences)
- No auto-tapping, accessibility automation, game control, or network permissions

## Build APK
1. Install Android Studio on a Windows PC.
2. Open this project folder in Android Studio.
3. Let Gradle sync. Use JDK 17 if Android Studio asks.
4. Select Build > Build APK(s).
5. The debug APK is usually created at `app/build/outputs/apk/debug/app-debug.apk`.

This is source code, not a precompiled APK. Internet may be required on first Gradle sync to download Android Gradle Plugin.
