package com.example.efootballhelper;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    final int navy = Color.rgb(16,28,50), blue = Color.rgb(27,117,188), pale = Color.rgb(239,245,252);
    LinearLayout root, content;
    SharedPreferences prefs;
    int wins, draws, losses, goalsFor, goalsAgainst;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("matches", MODE_PRIVATE);
        wins=prefs.getInt("wins",0); draws=prefs.getInt("draws",0); losses=prefs.getInt("losses",0);
        goalsFor=prefs.getInt("gf",0); goalsAgainst=prefs.getInt("ga",0);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(pale);
        setContentView(root);
        TextView header = new TextView(this); header.setText("⚽  eFootball Helper"); header.setTextSize(23); header.setTextColor(Color.WHITE);
        header.setTypeface(null,1); header.setPadding(20,22,16,22); header.setBackgroundColor(navy); root.addView(header);
        HorizontalScrollView hsv = new HorizontalScrollView(this);
        LinearLayout nav = new LinearLayout(this); nav.setPadding(8,8,8,8); nav.setBackgroundColor(Color.WHITE);
        String[] tabs={"Home","Match Guide","Team Builder","Match Tracker"};
        for(String tab:tabs){ Button btn=new Button(this); btn.setText(tab); btn.setTextSize(12); btn.setAllCaps(false);
            nav.addView(btn); btn.setOnClickListener(v->show(tab)); }
        hsv.addView(nav); root.addView(hsv);
        ScrollView scroll=new ScrollView(this); content=new LinearLayout(this); content.setPadding(16,16,16,24); content.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(content); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        show("Home");
    }
    TextView text(String s,int size,boolean bold) {
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(navy); t.setPadding(4,7,4,7);
        if(bold)t.setTypeface(null,1); return t;
    }
    void card(String title,String body) {
        LinearLayout box=new LinearLayout(this); box.setOrientation(1); box.setPadding(14,10,14,10); box.setBackgroundColor(Color.WHITE);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.bottomMargin=12;
        box.addView(text(title,18,true)); box.addView(text(body,15,false)); content.addView(box,lp);
    }
    void show(String tab) {
        content.removeAllViews();
        if(tab.equals("Home")) {
            content.addView(text("YOUR MATCHDAY COMPANION",13,true));
            card("Match Guide","Quick tips for attacking, defending and making safer decisions.");
            card("Argentina Team Builder","Explore formations such as 4-2-3-1 and 4-3-3. Your available players and playstyle should decide the final setup.");
            card("Match Tracker", wins+" wins  •  "+draws+" draws  •  "+losses+" losses");
            card("Safe use","This app gives advice only. It does not tap the screen, control eFootball, or automate matches.");
        } else if(tab.equals("Match Guide")) {
            card("ATTACK","• Pass to a free teammate instead of forcing a through ball.\n• Use sprint in open space, not constantly.\n• Shoot when balanced and in a clear position.\n• If crowded, recycle possession.");
            card("DEFENSE","• Switch to a defender early when danger develops.\n• Use Match-up to block passing lanes.\n• Avoid rushing a centre-back out of position.\n• Tackle when close and well positioned.");
            card("QUICK COUNTER","Win the ball, look forward quickly, and use a safe pass if the forward lane is blocked.");
        } else if(tab.equals("Team Builder")) {
            card("ARGENTINA","Choosing Argentina as your Base Team changes team identity; it does not automatically add real Argentina players to your Dream Team.");
            card("4-2-3-1","Balanced option: one CF, three attacking midfield/wing roles, two defensive midfielders, back four. Useful if you want protection behind the attack.");
            card("4-3-3","Wider attack: CF plus two wide forwards and a three-player midfield. Can stretch the opponent but may leave space if midfield loses the ball.");
            card("PLAYER SELECTION","Prioritise players that fit your playstyle, position and available GP. Do not spend GP just to chase a famous name.");
        } else {
            content.addView(text("MATCH RESULT TRACKER",20,true));
            content.addView(text("Record each match. Data is saved on this phone.",14,false));
            content.addView(text("Wins: "+wins+"     Draws: "+draws+"     Losses: "+losses,17,true));
            content.addView(text("Goals for: "+goalsFor+"     Goals against: "+goalsAgainst,16,false));
            Button add=new Button(this); add.setText("＋ Add Match Result"); add.setAllCaps(false); add.setBackgroundTintList(android.content.res.ColorStateList.valueOf(blue)); add.setTextColor(Color.WHITE);
            content.addView(add); add.setOnClickListener(v->addResult());
            Button reset=new Button(this); reset.setText("Reset Match Stats"); reset.setAllCaps(false); content.addView(reset);
            reset.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Reset stats?").setMessage("This will clear your saved match record.")
                .setNegativeButton("Cancel",null).setPositiveButton("Reset",(d,w)->{wins=draws=losses=goalsFor=goalsAgainst=0;save();show("Match Tracker");}).show());
        }
    }
    void addResult() {
        final String[] results={"Win","Draw","Loss"};
        LinearLayout form=new LinearLayout(this); form.setOrientation(1); form.setPadding(20,8,20,0);
        Spinner result=new Spinner(this); result.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,results)); form.addView(result);
        EditText gf=new EditText(this); gf.setHint("Goals scored"); gf.setInputType(2); form.addView(gf);
        EditText ga=new EditText(this); ga.setHint("Goals conceded"); ga.setInputType(2); form.addView(ga);
        new AlertDialog.Builder(this).setTitle("Add Match").setView(form).setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->{
            int a=parse(gf.getText().toString()), b=parse(ga.getText().toString());
            String r=results[result.getSelectedItemPosition()];
            if(r.equals("Win"))wins++; else if(r.equals("Draw"))draws++; else losses++;
            goalsFor+=a; goalsAgainst+=b; save(); show("Match Tracker");
        }).show();
    }
    int parse(String s){try{return Math.max(0,Integer.parseInt(s));}catch(Exception e){return 0;}}
    void save(){prefs.edit().putInt("wins",wins).putInt("draws",draws).putInt("losses",losses).putInt("gf",goalsFor).putInt("ga",goalsAgainst).apply();}
}
